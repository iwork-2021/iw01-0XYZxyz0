//
//  Calculator.swift
//  MyCalculator
//
//  Created by nju on 2021/10/14.
//

import UIKit

class Calculator: NSObject {
    enum Operation {
        case UnaryOp((Double)->Double)
        case BinaryOp((Double,Double)->Double)
        case EqualOp
        case Constant(Double)
    }
    
    var operations = [
        "EE": Operation.BinaryOp{
            (op1, op2) in
            return op1*pow(10,op2)
        },
        
        "1/x": Operation.UnaryOp{
            op in
            return 1/op
        },
        
        "e^x": Operation.UnaryOp{
            op in
            return pow(2.72,op)
        },
        
        "10^x": Operation.UnaryOp{
            op in
            return pow(10,op)
        },
        
        "ln": Operation.UnaryOp{
            op in
            return log(op)/log(2.72)
        },
        
        "lg": Operation.UnaryOp{
            op in
            return log(op)/log(10)
        },
        
        "x^2": Operation.UnaryOp{
            op in
            return pow(op,2)
        },
        
        "x^3": Operation.UnaryOp{
            op in
            return pow(op,3)
        },
        
        "x^y": Operation.BinaryOp{
            (op1, op2) in
            return pow(op1,op2)
        },
        
        "2√x": Operation.UnaryOp{
            op in
            return pow(op,1/2)
        },
        
        "3√x": Operation.UnaryOp{
            op in
            return pow(op,1/3)
        },
        
        "y√x": Operation.BinaryOp{
            (op1, op2) in
            return pow(op1,1/op2)
        },
        
        "sin": Operation.UnaryOp{
            op in
            return sin(op)
        },
        
        "cos": Operation.UnaryOp{
            op in
            return cos(op)
        },
        
        "tan": Operation.UnaryOp{
            op in
            return tan(op)
        },
        
        "sinh": Operation.UnaryOp{
            op in
            return sinh(op)
        },
        
        "cosh": Operation.UnaryOp{
            op in
            return cosh(op)
        },
        
        "tanh": Operation.UnaryOp{
            op in
            return tanh(op)
        },
        
        "+": Operation.BinaryOp{
            (op1, op2) in
            return op1 + op2
        },
        
        "-": Operation.BinaryOp{
            (op1, op2) in
            return op1 - op2
        },
        
        "*": Operation.BinaryOp{
            (op1, op2) in
            return op1 * op2
        },
        
        "/": Operation.BinaryOp{
            (op1, op2) in
            return op1 / op2
        },
        
        "=": Operation.EqualOp,
        
        "%": Operation.UnaryOp{
            op in
            return op / 100.0
        },
        
        "+/-": Operation.UnaryOp{
            op in
            return -op
        },
        
        "Clear": Operation.UnaryOp{
            _ in
            return 0
        },
        
        "pi": Operation.Constant(3.14),
        
        "e": Operation.Constant(2.72)
    ]
    
    struct Intermediate{
        var firstOp: Double
        var waitingOperation:(Double,Double) -> Double
    }
    
    var pendingOp:Intermediate? = nil
    
    func performOperation(operation:String, operand:Double)->Double? {
        if let op = operations[operation] {
            switch op {
            case .BinaryOp(let function):
                pendingOp = Intermediate(firstOp: operand,waitingOperation: function)
                return nil
            case .Constant(let value):
                return value
            case .EqualOp:
                return pendingOp!.waitingOperation(pendingOp!.firstOp, operand)
            case .UnaryOp(let function):
                return function(operand)
            }
        }
        return nil
    }
}
