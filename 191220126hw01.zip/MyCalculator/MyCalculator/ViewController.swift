//
//  ViewController.swift
//  MyCalculator
//
//  Created by nju on 2021/10/14.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var DisplayLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.DisplayLabel.text! = ""
    }
    var digitOnDisplay: String{
        get{
            return self.DisplayLabel.text!
        }
        set{
            self.DisplayLabel.text! = newValue
        }
    }
    
    var inTypingMode = false
    
    @IBAction func NumberTouched(_ sender: UIButton) {
        if inTypingMode{
            digitOnDisplay = digitOnDisplay + sender.currentTitle!
        }else{
            digitOnDisplay = sender.currentTitle!
            inTypingMode = true
        }
    }
    
    let calculator = Calculator()
    @IBAction func OpreatorTouched(_ sender: UIButton) {
        if let op = sender.currentTitle{
            if let result = calculator.performOperation(operation: op, operand: Double(digitOnDisplay)!){
                digitOnDisplay = String(result)
            }
            inTypingMode = false
        }
    }
}

